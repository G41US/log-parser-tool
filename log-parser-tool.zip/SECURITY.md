# Security Policy

⚠️ This project is for **educational and defensive purposes only**.  
Do not use against systems you do not own or have explicit permission to test.

If you find issues in this repo (e.g., bugs, security problems), please open an Issue or contact me privately.
